import java.util.Scanner;

public class Test_2438 {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			int a, b, c;
			
			a = sc.nextInt();
			
			for(b = 1; b <= a; b++) {
				;System.out.println();
				for(c=1; c<=b; c++) {
					System.out.print("★");
				}
				
			}
			
			sc.close();
			}

}
